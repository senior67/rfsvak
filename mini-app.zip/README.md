# excuse-vk-mini-app
Vk Mini App for excuses
